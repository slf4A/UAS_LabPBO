import java.util.ArrayList;

abstract class Driver {
}

public class AdminDriver extends Driver {
    private Admin akun;
    private ListBarang listBarang;
    private ArrayList<Transaksi> listTransaksi;

    // Constructor
    public AdminDriver(Admin akun, ListBarang listBarang) {
        this.akun = akun;
        this.listBarang = listBarang;
        this.listTransaksi = new ArrayList<>();
    }

    // Getter dan Setter untuk akun, listBarang, dan listTransaksi
    public Admin getAkun() {
        return akun;
    }

    public void setAkun(Admin akun) {
        this.akun = akun;
    }

    public ListBarang getListBarang() {
        return listBarang;
    }

    public void setListBarang(ListBarang listBarang) {
        this.listBarang = listBarang;
    }

    public ArrayList<Transaksi> getListTransaksi() {
        return listTransaksi;
    }

    // Method untuk menambah transaksi
    public void addTransaksi(Transaksi transaksi) {
        this.listTransaksi.add(transaksi);
    }
}