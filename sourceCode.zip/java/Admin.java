import java.io.*;

public class Admin extends Akun {
    private String username;
    private String email;
    private String password;

    // Constructor
    public Admin(String username, String email, String password) {
        super(username);  // Memanggil constructor dari superclass Akun
        this.username = username;
        this.email = email;
        this.password = password;
    }

    // Getter dan Setter
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    // Validasi password
    public boolean validatePassword(String inputPassword) {
        return this.password.equals(inputPassword);
    }

    // Method to change password
    public void changePassword(String newPassword) {
        this.password = newPassword;
    }

    // Method to display admin details
    public void displayAdminInfo() {
        System.out.println("Username: " + username);
        System.out.println("Email: " + email);
        System.out.println("Password: " + password);
    }

    // Menyimpan informasi admin ke file
    public void saveToFile(String filePath) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true))) {
            int entryNumber = getEntryCount(filePath) + 1;
            writer.write(entryNumber + ". Username: " + username + "\n");
            writer.write("   Email: " + email + "\n");
            writer.write("   Password: " + password + "\n");
            writer.newLine();
        } catch (IOException e) {
            System.out.println("Error saving admin to file: " + e.getMessage());
        }
    }

    // Membaca informasi admin dari file
    public static Admin loadFromFile(String filePath, String usernameToFind) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains("Username: " + usernameToFind)) {
                    String email = reader.readLine().split(": ")[1].trim();
                    String password = reader.readLine().split(": ")[1].trim();
                    return new Admin(usernameToFind, email, password);
                }
            }
            System.out.println("Admin not found.");
        } catch (IOException e) {
            System.out.println("Error reading admin from file: " + e.getMessage());
        }
        return null;
    }

    // Menghitung jumlah entri dalam file
    private int getEntryCount(String filePath) {
        int count = 0;
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("1. Username: ") || line.matches("\\d+\\. Username: .*")) {
                    count++;
                }
            }
        } catch (IOException e) {
            System.out.println("Error counting entries: " + e.getMessage());
        }
        return count;
    }

    // Method to validate admin login
    public static boolean validateAdminLogin(String filePath, String usernameToFind, String inputPassword) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains("Username: " + usernameToFind)) {
                    String email = reader.readLine().split(": ")[1].trim(); // Skip email
                    String password = reader.readLine().split(": ")[1].trim();
                    return password.equals(inputPassword); // Validate password
                }
            }
            System.out.println("Admin tidak ditemukan.");
        } catch (IOException e) {
            System.out.println("Error reading admin from file: " + e.getMessage());
        }
        return false;
    }

    
}
